import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qgis
import org.qfield
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var positionSource: iface.findItemByObjectName('positionSource')
    property var dashBoard: iface.findItemByObjectName('dashBoard')

    // Contador correlativo de puntos
    property int contadorPunto: 1

    // Historial en memoria para graficar el perfil
    // Estructura: { punto, red, valvula, x, y, z, distAcum, est, usuario }
    property var historialPuntos: []

    // Lista dinámica de redes para los desplegables
    property var listaRedes: ["Principal", "Ramal_1", "Ramal_2", "Ramal_3"]

    // Índice del punto seleccionado actualmente en el visor de perfil
    property int indicePuntoPerfil: -1

    // Catálogo de elementos (NODO en índice 0 para auto-retorno)
    ListModel {
        id: catalogoValvulas
        ListElement { codigo: "NODO"; etiqueta: "NODO - Punto Normal (Vacío)" }
        ListElement { codigo: "VA";   etiqueta: "VA - Válvula de Aire" }
        ListElement { codigo: "TQ";   etiqueta: "TQ - Tanque Quiebragradiente" }
        ListElement { codigo: "FT";   etiqueta: "FT - Filtrado" }
        ListElement { codigo: "VT";   etiqueta: "VT - Toma Parcelaria" }
        ListElement { codigo: "AB";   etiqueta: "AB - Abrevadero" }
        ListElement { codigo: "VCL";  etiqueta: "VCL - Válvula Compuerta" }
        ListElement { codigo: "VM";   etiqueta: "VM - Válvula Mariposa" }
        ListElement { codigo: "VL";   etiqueta: "VL - Válvula Limpieza" }
        ListElement { codigo: "VR";   etiqueta: "VR - Válvula Reguladora" }
        ListElement { codigo: "VS";   etiqueta: "VS - Válvula Sostenedora" }
        ListElement { codigo: "VAL";  etiqueta: "VAL - Válvula Alivio" }
        ListElement { codigo: "PT";   etiqueta: "PT - Puente Tubo" }
        ListElement { codigo: "PA";   etiqueta: "PA - Paso Aéreo" }
        ListElement { codigo: "D";    etiqueta: "D - Desarenador" }
        ListElement { codigo: "T";    etiqueta: "T - Presa / Captación" }
        ListElement { codigo: "R";    etiqueta: "R - Reservorio" }
        ListElement { codigo: "MD";   etiqueta: "MD - Medidor de Caudal" }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(btnPlugin)
    }

    // Refrescar el perfil automáticamente cuando cambia la posición del GPS
    Connections {
        target: positionSource
        function onPositionInformationChanged() {
            if (panelCaptura.visible && contenedorPerfil.visible) {
                canvasPerfil.requestPaint()
            }
        }
    }

    // Formatear distancia como estacionamiento (ej. 0+125.4)
    function formatearEstacionamiento(distancia) {
        var km = Math.floor(distancia / 1000);
        var m = (distancia % 1000).toFixed(1);
        var mStr = (distancia % 1000) < 10 ? "00" + m : ((distancia % 1000) < 100 ? "0" + m : "" + m);
        return km + "+" + mStr;
    }

    // Obtener puntos filtrados por la red seleccionada en el perfil
    function obtenerPuntosPerfil() {
        var redObj = comboRedPerfil.currentText || "Principal";
        var pts = [];
        for (var i = 0; i < plugin.historialPuntos.length; i++) {
            if (plugin.historialPuntos[i].red === redObj) {
                pts.push(plugin.historialPuntos[i]);
            }
        }
        return pts;
    }

    // Agregar una nueva red a la lista sin duplicar
    function registrarNuevaRed(nombreRed) {
        var n = nombreRed.trim();
        if (n === "") return;
        var copia = plugin.listaRedes.slice();
        if (copia.indexOf(n) === -1) {
            copia.push(n);
            plugin.listaRedes = copia;
        }
        var idx = plugin.listaRedes.indexOf(n);
        comboRed.currentIndex = idx;
        comboRed.editText = n;
    }

    // Crear siguiente Ramal principal (Ramal_1 -> Ramal_2 -> Ramal_3)
    function crearSiguienteRamal() {
        var maxNum = 0;
        for (var i = 0; i < plugin.listaRedes.length; i++) {
            var m = plugin.listaRedes[i].match(/^Ramal_(\d+)$/);
            if (m) {
                var num = parseInt(m[1]);
                if (num > maxNum) maxNum = num;
            }
        }
        registrarNuevaRed("Ramal_" + (maxNum + 1));
    }

    // Crear Subramal jerárquico (Ramal_1 -> Ramal_1.1 -> Ramal_1.1.1)
    function crearSubRamal() {
        var actual = comboRed.editText.trim();
        if (actual === "" || actual === "Principal") {
            actual = "Ramal_1";
        }
        var prefijo = actual + ".";
        var maxSub = 0;
        for (var i = 0; i < plugin.listaRedes.length; i++) {
            var item = plugin.listaRedes[i];
            if (item.indexOf(prefijo) === 0) {
                var resto = item.substring(prefijo.length);
                if (/^\d+$/.test(resto)) {
                    var n = parseInt(resto);
                    if (n > maxSub) maxSub = n;
                }
            }
        }
        registrarNuevaRed(prefijo + (maxSub + 1));
    }

    // 1. Botón en barra de complementos
    QfToolButton {
        id: btnPlugin
        iconSource: Theme.getThemeVectorIcon('ic_add_geometry_white_24dp')
        iconColor: Theme.mainColor
        bgcolor: Theme.darkGray
        round: true
        onClicked: {
            panelCaptura.visible = !panelCaptura.visible
        }
    }

    // 2. Banner Superior Permanente de Elevación
    Rectangle {
        id: barraElevacion
        parent: mainWindow.contentItem
        anchors.top: parent.top
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.topMargin: 10
        width: 260
        height: 44
        radius: 8
        color: "#D9111111"
        border.color: "#33a02c"
        border.width: 2
        z: 9999

        Text {
            anchors.centerIn: parent
            color: "#00FFFF"
            font.pixelSize: 19
            font.bold: true
            text: {
                if (positionSource && positionSource.active && positionSource.positionInformation) {
                    var z = positionSource.positionInformation.elevation;
                    return !isNaN(z) ? "⛰️ Z: " + z.toFixed(1) + " m.s.n.m." : "⛰️ Z: Sin señal 3D";
                }
                return "⚠️ GPS Inactivo";
            }
        }
    }

    // 3. Panel Principal de Captura y Perfil
    Rectangle {
        id: panelCaptura
        parent: mainWindow.contentItem
        visible: false
        width: Math.min(parent.width * 0.96, 420)
        height: colPrincipal.implicitHeight + 24
        anchors.bottom: parent.bottom
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottomMargin: 16
        radius: 12
        color: "#F21E1E1E"
        border.color: "#1f78b4"
        border.width: 2
        z: 10000

        ColumnLayout {
            id: colPrincipal
            anchors.fill: parent
            anchors.margins: 12
            spacing: 8

            // Encabezado
            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: "Levantamiento de Tubería"
                    color: "white"
                    font.pixelSize: 16
                    font.bold: true
                    Layout.fillWidth: true
                }
                Button {
                    text: contenedorPerfil.visible ? "🔽 Ocultar Perfil" : "📈 Ver Perfil"
                    onClicked: {
                        contenedorPerfil.visible = !contenedorPerfil.visible
                        if (contenedorPerfil.visible) {
                            var pts = obtenerPuntosPerfil();
                            plugin.indicePuntoPerfil = pts.length - 1;
                            canvasPerfil.requestPaint();
                        }
                    }
                }
                Button {
                    text: "✕"
                    onClicked: panelCaptura.visible = false
                }
            }

            // Selector de RED con generadores de Ramal_X y Subramales (Ramal_X.Y.Z)
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "RED:"; color: "#CCCCCC"; font.bold: true; Layout.preferredWidth: 55 }
                ComboBox {
                    id: comboRed
                    Layout.fillWidth: true
                    editable: true
                    model: plugin.listaRedes
                }
                Button {
                    text: "+Ramal"
                    ToolTip.visible: down
                    ToolTip.text: "Crear siguiente Ramal_N"
                    onClicked: crearSiguienteRamal()
                }
                Button {
                    text: "+Sub"
                    ToolTip.visible: down
                    ToolTip.text: "Crear subramal (ej. Ramal_1.1)"
                    onClicked: crearSubRamal()
                }
            }

            // Selector de VALVULA (Auto-regresa a NODO tras guardar)
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "VALVULA:"; color: "#CCCCCC"; font.bold: true; Layout.preferredWidth: 68 }
                ComboBox {
                    id: comboElemento
                    Layout.fillWidth: true
                    model: catalogoValvulas
                    textRole: "etiqueta"
                    valueRole: "codigo"
                }
            }

            // Campo USUARIO siempre disponible
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "USUARIO:"; color: "#fdbf6f"; font.bold: true; Layout.preferredWidth: 68 }
                TextField {
                    id: txtUsuario
                    Layout.fillWidth: true
                    placeholderText: "Nombre del usuario (opcional)"
                    color: "white"
                    background: Rectangle {
                        color: "#333333"
                        radius: 4
                        border.color: "#555555"
                    }
                }
            }

            // 4. Bloque del Perfil Longitudinal Interactivo
            Rectangle {
                id: contenedorPerfil
                visible: false
                Layout.fillWidth: true
                Layout.preferredHeight: 285
                color: "#141414"
                radius: 8
                border.color: "#444444"
                border.width: 1

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 8
                    spacing: 6

                    // Selector independiente para elegir qué Red ver en el perfil (Por defecto: Principal)
                    RowLayout {
                        Layout.fillWidth: true
                        Text { text: "Perfil de:"; color: "#00FFFF"; font.bold: true; font.pixelSize: 13 }
                        ComboBox {
                            id: comboRedPerfil
                            Layout.fillWidth: true
                            model: plugin.listaRedes
                            currentIndex: 0 // "Principal" por defecto
                            onCurrentTextChanged: {
                                var pts = obtenerPuntosPerfil();
                                plugin.indicePuntoPerfil = pts.length - 1;
                                canvasPerfil.requestPaint();
                            }
                        }
                    }

                    // Lienzo del gráfico del perfil
                    Canvas {
                        id: canvasPerfil
                        Layout.fillWidth: true
                        Layout.fillHeight: true

                        onPaint: {
                            var ctx = getContext("2d");
                            ctx.reset();
                            ctx.clearRect(0, 0, width, height);

                            var pts = obtenerPuntosPerfil();
                            var redMostrada = comboRedPerfil.currentText || "Principal";

                            // Calcular posición GPS actual proyectada sobre este perfil
                            var gpsActivo = false;
                            var gpsZ = 0.0;
                            var gpsDist = 0.0;
                            var capa = obtenerCapaDestino();

                            if (positionSource && positionSource.active && positionSource.positionInformation && capa) {
                                var pos = positionSource.positionInformation;
                                if (!isNaN(pos.elevation) && !isNaN(pos.longitude)) {
                                    gpsActivo = true;
                                    gpsZ = pos.elevation;
                                    var pWgs = GeometryUtils.point(pos.longitude, pos.latitude);
                                    var crsWgs = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326");
                                    var pMap = GeometryUtils.reprojectPoint(pWgs, crsWgs, capa.crs);

                                    if (pts.length > 0) {
                                        var ult = pts[pts.length - 1];
                                        var dx = pMap.x - ult.x;
                                        var dy = pMap.y - ult.y;
                                        gpsDist = ult.distAcum + Math.sqrt(dx * dx + dy * dy);
                                    } else {
                                        gpsDist = 0.0;
                                    }
                                }
                            }

                            if (pts.length === 0) {
                                ctx.fillStyle = "#AAAAAA";
                                ctx.font = "12px sans-serif";
                                ctx.fillText("Sin puntos registrados aún en '" + redMostrada + "'.", 10, height / 2);
                                return;
                            }

                            // Determinar límites X (distancia) y Y (elevación)
                            var minZ = pts[0].z, maxZ = pts[0].z;
                            var maxDist = pts[pts.length - 1].distAcum;

                            for (var i = 1; i < pts.length; i++) {
                                if (pts[i].z < minZ) minZ = pts[i].z;
                                if (pts[i].z > maxZ) maxZ = pts[i].z;
                            }
                            if (gpsActivo) {
                                if (gpsZ < minZ) minZ = gpsZ;
                                if (gpsZ > maxZ) maxZ = gpsZ;
                                if (gpsDist > maxDist) maxDist = gpsDist;
                            }

                            if (Math.abs(maxZ - minZ) < 2.0) {
                                maxZ += 1.0;
                                minZ -= 1.0;
                            }
                            if (maxDist <= 0.1) maxDist = 10.0;

                            var padL = 42, padR = 16, padT = 18, padB = 20;
                            var w = width - padL - padR;
                            var h = height - padT - padB;

                            // Dibujar ejes
                            ctx.strokeStyle = "#444444";
                            ctx.lineWidth = 1;
                            ctx.beginPath();
                            ctx.moveTo(padL, padT);
                            ctx.lineTo(padL, padT + h);
                            ctx.lineTo(padL + w, padT + h);
                            ctx.stroke();

                            // Etiquetas de ejes
                            ctx.fillStyle = "#CCCCCC";
                            ctx.font = "10px sans-serif";
                            ctx.fillText(maxZ.toFixed(0) + "m", 2, padT + 8);
                            ctx.fillText(minZ.toFixed(0) + "m", 2, padT + h);
                            ctx.fillText("0+000", padL, height - 4);
                            ctx.fillText(formatearEstacionamiento(maxDist), padL + w - 45, height - 4);

                            // Dibujar rasante de tubería levantada
                            ctx.strokeStyle = "#33a02c";
                            ctx.lineWidth = 2.5;
                            ctx.beginPath();
                            for (var k = 0; k < pts.length; k++) {
                                var px = padL + (pts[k].distAcum / maxDist) * w;
                                var py = padT + h - ((pts[k].z - minZ) / (maxZ - minZ)) * h;
                                if (k === 0) ctx.moveTo(px, py);
                                else ctx.lineTo(px, py);
                            }
                            ctx.stroke();

                            // Línea punteada hacia tu ubicación GPS actual
                            if (gpsActivo && pts.length > 0) {
                                var ultPx = padL + (pts[pts.length - 1].distAcum / maxDist) * w;
                                var ultPy = padT + h - ((pts[pts.length - 1].z - minZ) / (maxZ - minZ)) * h;
                                var gpsPx = padL + (gpsDist / maxDist) * w;
                                var gpsPy = padT + h - ((gpsZ - minZ) / (maxZ - minZ)) * h;

                                ctx.strokeStyle = "#00FFFF";
                                ctx.lineWidth = 1.5;
                                ctx.setLineDash([4, 4]);
                                ctx.beginPath();
                                ctx.moveTo(ultPx, ultPy);
                                ctx.lineTo(gpsPx, gpsPy);
                                ctx.stroke();
                                ctx.setLineDash([]);

                                // Marcador de tu ubicación actual (Cian)
                                ctx.fillStyle = "#00FFFF";
                                ctx.beginPath();
                                ctx.arc(gpsPx, gpsPy, 5, 0, 2 * Math.PI);
                                ctx.fill();
                                ctx.fillText("Tú", gpsPx - 8, gpsPy - 8);
                            }

                            // Dibujar nodos y resaltar el nodo seleccionado con los botones
                            for (var m = 0; m < pts.length; m++) {
                                var nx = padL + (pts[m].distAcum / maxDist) * w;
                                var ny = padT + h - ((pts[m].z - minZ) / (maxZ - minZ)) * h;

                                // Si es el punto actualmente inspeccionado, dibujar guía vertical amarilla
                                if (m === plugin.indicePuntoPerfil) {
                                    ctx.strokeStyle = "#FFFF00";
                                    ctx.lineWidth = 1;
                                    ctx.beginPath();
                                    ctx.moveTo(nx, padT);
                                    ctx.lineTo(nx, padT + h);
                                    ctx.stroke();

                                    ctx.fillStyle = "#FFFF00";
                                    ctx.beginPath();
                                    ctx.arc(nx, ny, 6.5, 0, 2 * Math.PI);
                                    ctx.fill();
                                }

                                ctx.beginPath();
                                if (pts[m].valvula !== "") {
                                    ctx.fillStyle = "#e31a1c"; // Rojo para válvulas/obras
                                    ctx.arc(nx, ny, 4, 0, 2 * Math.PI);
                                    ctx.fill();

                                    ctx.fillStyle = "#fdbf6f";
                                    ctx.font = "bold 9px sans-serif";
                                    ctx.fillText(pts[m].valvula, nx - 7, ny - 8);
                                } else {
                                    ctx.fillStyle = "#FFFFFF"; // Blanco para punto normal
                                    ctx.arc(nx, ny, 2.5, 0, 2 * Math.PI);
                                    ctx.fill();
                                }
                            }
                        }
                    }

                    // Controles de navegación (Atrás / Siguiente) + Detalle del punto seleccionado
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6

                        Button {
                            text: "◀ Ant."
                            Layout.preferredWidth: 68
                            onClicked: {
                                var pts = obtenerPuntosPerfil();
                                if (pts.length === 0) return;
                                if (plugin.indicePuntoPerfil > 0) {
                                    plugin.indicePuntoPerfil -= 1;
                                } else {
                                    plugin.indicePuntoPerfil = 0;
                                }
                                canvasPerfil.requestPaint();
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            height: 38
                            color: "#222222"
                            radius: 4
                            border.color: "#FFFF00"
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                color: "white"
                                font.pixelSize: 11
                                font.bold: true
                                horizontalAlignment: Text.AlignHCenter
                                text: {
                                    var pts = obtenerPuntosPerfil();
                                    var idx = plugin.indicePuntoPerfil;
                                    if (pts.length === 0 || idx < 0 || idx >= pts.length) {
                                        return "Sin punto seleccionado";
                                    }
                                    var p = pts[idx];
                                    var tipo = p.valvula === "" ? "NODO" : p.valvula;
                                    var usr = p.usuario !== "" ? " | Usr: " + p.usuario : "";
                                    return "Pto #" + p.punto + " [" + tipo + "] | Est: " + p.est + "\nZ: " + p.z.toFixed(1) + " m" + usr;
                                }
                            }
                        }

                        Button {
                            text: "Sig. ▶"
                            Layout.preferredWidth: 68
                            onClicked: {
                                var pts = obtenerPuntosPerfil();
                                if (pts.length === 0) return;
                                if (plugin.indicePuntoPerfil < pts.length - 1) {
                                    plugin.indicePuntoPerfil += 1;
                                } else {
                                    plugin.indicePuntoPerfil = pts.length - 1;
                                }
                                canvasPerfil.requestPaint();
                            }
                        }
                    }
                }
            }

            // Botón Principal de Captura
            Button {
                Layout.fillWidth: true
                Layout.preferredHeight: 48
                text: "📍 REGISTRAR PUNTO (#" + plugin.contadorPunto + ")"
                font.bold: true
                font.pixelSize: 15
                background: Rectangle {
                    color: parent.down ? "#23701e" : "#33a02c"
                    radius: 8
                }
                contentItem: Text {
                    text: parent.text
                    color: "white"
                    font: parent.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                onClicked: registrarPuntoEnCapa()
            }
        }
    }

    // Identificar capa de puntos activa o buscar ObrasCiviles / Nodos
    function obtenerCapaDestino() {
        var layer = dashBoard ? dashBoard.activeLayer : null;
        if (layer && layer.geometryType() === Qgis.GeometryType.Point) {
            return layer;
        }
        var capas = ProjectUtils.mapLayers(qgisProject);
        for (var id in capas) {
            var l = capas[id];
            var nombre = l.name.toLowerCase();
            if (nombre.indexOf("obrasciviles") !== -1 || nombre.indexOf("nodos") !== -1 || nombre.indexOf("levantamiento") !== -1) {
                return l;
            }
        }
        return layer;
    }

    function registrarPuntoEnCapa() {
        if (!positionSource || !positionSource.active || !positionSource.positionInformation) {
            mainWindow.displayToast("⚠️ El GPS no está activo o no tiene posición.");
            return;
        }

        var capa = obtenerCapaDestino();
        if (!capa) {
            mainWindow.displayToast("⚠️ Selecciona primero una capa de puntos en QField.");
            return;
        }

        var pos = positionSource.positionInformation;
        var lon = pos.longitude;
        var lat = pos.latitude;
        var elev = isNaN(pos.elevation) ? 0.0 : pos.elevation;

        // Reproyectar de WGS84 (EPSG:4326) al CRS de la capa (ej. EPSG:5367 CRTM05)
        var puntoWgs84 = GeometryUtils.point(lon, lat);
        var crsWgs84 = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326");
        var puntoTransformado = GeometryUtils.reprojectPoint(puntoWgs84, crsWgs84, capa.crs);

        var xActual = puntoTransformado.x;
        var yActual = puntoTransformado.y;
        var redSeleccionada = comboRed.editText.trim();
        if (redSeleccionada === "") redSeleccionada = "Principal";

        // Asegurar que la red escrita manualmente también aparezca en el selector del perfil
        registrarNuevaRed(redSeleccionada);

        var codigoSeleccionado = catalogoValvulas.get(comboElemento.currentIndex).codigo;
        // REGLA: Si es NODO, el campo VALVULA queda vacío ("")
        var valorValvula = (codigoSeleccionado === "NODO") ? "" : codigoSeleccionado;
        var textoUsuario = txtUsuario.text.trim();

        // Calcular distancia acumulada dentro de esa misma RED
        var distAcumulada = 0.0;
        for (var i = plugin.historialPuntos.length - 1; i >= 0; i--) {
            if (plugin.historialPuntos[i].red === redSeleccionada) {
                var dx = xActual - plugin.historialPuntos[i].x;
                var dy = yActual - plugin.historialPuntos[i].y;
                distAcumulada = plugin.historialPuntos[i].distAcum + Math.sqrt(dx * dx + dy * dy);
                break;
            }
        }
        var estTexto = formatearEstacionamiento(distAcumulada);

        var wkt = "POINT(" + xActual + " " + yActual + ")";
        var geom = GeometryUtils.createGeometryFromWkt(wkt);
        var feature = FeatureUtils.createFeature(capa, geom);

        var campos = capa.fields.names;
        function setSiExiste(nombreCampo, valor) {
            for (var c = 0; c < campos.length; c++) {
                if (campos[c].toUpperCase() === nombreCampo.toUpperCase()) {
                    feature.setAttribute(c, valor);
                    break;
                }
            }
        }

        setSiExiste("PUNTO", plugin.contadorPunto);
        setSiExiste("ID", plugin.contadorPunto);
        setSiExiste("COORDEX", Math.round(xActual * 100) / 100);
        setSiExiste("COORDEY", Math.round(yActual * 100) / 100);
        setSiExiste("ELEVACION", Math.round(elev * 100) / 100);
        setSiExiste("VALVULA", valorValvula); // "" si es NODO, o "VA", "TQ", "FT", etc.
        setSiExiste("RED", redSeleccionada);  // "Principal", "Ramal_1", "Ramal_1.1", etc.
        setSiExiste("USUARIO", textoUsuario);
        setSiExiste("DISTANCIA", Math.round(distAcumulada * 100) / 100);
        setSiExiste("EST", estTexto);

        if (LayerUtils.addFeature(capa, feature)) {
            var nuevoHistorial = plugin.historialPuntos.slice();
            nuevoHistorial.push({
                punto: plugin.contadorPunto,
                red: redSeleccionada,
                valvula: valorValvula,
                x: xActual,
                y: yActual,
                z: elev,
                distAcum: distAcumulada,
                est: estTexto,
                usuario: textoUsuario
            });
            plugin.historialPuntos = nuevoHistorial;

            // Seleccionar automáticamente el último punto registrado de la red vista en el perfil
            var ptsPerfil = obtenerPuntosPerfil();
            plugin.indicePuntoPerfil = ptsPerfil.length - 1;
            if (contenedorPerfil.visible) {
                canvasPerfil.requestPaint();
            }

            var etiquetaToast = valorValvula === "" ? "NODO (Vacío)" : valorValvula;
            mainWindow.displayToast("✅ #" + plugin.contadorPunto + " [" + etiquetaToast + "] en " + redSeleccionada + " | Z: " + elev.toFixed(1) + " m");
            plugin.contadorPunto += 1;

            // Regresar siempre el selector a NODO y limpiar el campo USUARIO
            comboElemento.currentIndex = 0;
            txtUsuario.text = "";
        } else {
            mainWindow.displayToast("❌ Error al guardar el punto en la capa: " + capa.name);
        }
    }
}