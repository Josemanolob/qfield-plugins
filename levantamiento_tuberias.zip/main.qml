import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qgis
import org.qfield
import Theme

Item {
    id: plugin

    // Componentes nativos de QField
    property var mainWindow: iface.mainWindow()
    property var positionSource: iface.findItemByObjectName('positionSource')
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var mapCanvas: iface.mapCanvas()
    property var coordinateLocator: iface.findItemByObjectName('coordinateLocator')

    property int contadorPunto: 1
    property var historialPuntos: []
    property var listaRedes: ["Principal"]
    property int indicePuntoPerfil: -1
    property bool datosProyectoCargados: false

    // Estado de interfaz: permite minimizar el panel para no tapar el mapa
    property bool panelMinimizado: false
    // Permite elegir entre capturar en la Mira de QField (con soporte de paneo/snapping) o GPS directo
    property bool usarMiraQField: true

    property bool esPrincipal: comboRed.currentText === "Principal"

    ListModel {
        id: catalogoValvulas
        ListElement { codigo: "NODO"; etiqueta: "NODO - Punto Normal (Vacío)" }
        ListElement { codigo: "VA";   etiqueta: "VA - Válvula de Aire" }
        ListElement { codigo: "TQ";   etiqueta: "TQ - Tanque Quiebragradiente" }
        ListElement { codigo: "FT";   etiqueta: "FT - Filtrado" }
        ListElement { codigo: "VT";   etiqueta: "VT - Toma Parcelaria" }
        ListElement { codigo: "AB";   etiqueta: "AB - Abrevadero" }
        ListElement { codigo: "VCL";  etiqueta: "VCL - Válvula Compuerta" }
        ListElement { codigo: "VM";   etiqueta: "VM - Válvula Mariposa" }
        ListElement { codigo: "VL";   etiqueta: "VL - Válvula Limpieza" }
        ListElement { codigo: "VR";   etiqueta: "VR - Válvula Reguladora" }
        ListElement { codigo: "VS";   etiqueta: "VS - Válvula Sostenedora" }
        ListElement { codigo: "VAL";  etiqueta: "VAL - Válvula Alivio" }
        ListElement { codigo: "PT";   etiqueta: "PT - Puente Tubo" }
        ListElement { codigo: "PA";   etiqueta: "PA - Paso Aéreo" }
        ListElement { codigo: "D";    etiqueta: "D - Desarenador" }
        ListElement { codigo: "T";    etiqueta: "T - Presa / Captación" }
        ListElement { codigo: "R";    etiqueta: "R - Reservorio" }
        ListElement { codigo: "MD";   etiqueta: "MD - Medidor de Caudal" }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(btnPlugin)
    }

    Connections {
        target: positionSource
        function onPositionInformationChanged() {
            if (panelCaptura.visible && contenedorPerfil.visible) {
                canvasPerfil.requestPaint()
            }
        }
    }

    function obtenerCapaPorNombre(palabraClave) {
        var capas = ProjectUtils.mapLayers(qgisProject);
        var clave = palabraClave.toLowerCase();
        for (var id in capas) {
            var l = capas[id];
            if (l && l.name && l.name.toLowerCase().indexOf(clave) !== -1) {
                return l;
            }
        }
        return null;
    }

    // Lectura compatible con distintos nombres de columna en Nodos / ObrasCiviles
    function leerAtributoSeguro(feature, nombresPosibles) {
        for (var i = 0; i < nombresPosibles.length; i++) {
            var val = feature.attribute(nombresPosibles[i]);
            if (val !== undefined && val !== null && String(val).toLowerCase() !== "null") {
                return val;
            }
        }
        return null;
    }

    function sincronizarDesdeCapaNodos() {
        var capaNodos = obtenerCapaPorNombre("nodo") || obtenerCapaPorNombre("obra");
        if (!capaNodos) return;

        try {
            var it = LayerUtils.createFeatureIteratorFromExpression(capaNodos, "TRUE");
            var redesEncontradas = ["Principal"];
            var ptsTemp = [];
            var maxPunto = 0;

            while (it && it.hasNext()) {
                var f = it.next();
                var ptoRaw = leerAtributoSeguro(f, ["PUNTO", "punto", "ID", "id"]);
                var pto = parseInt(ptoRaw);
                if (!isNaN(pto) && pto > maxPunto) maxPunto = pto;

                var r = leerAtributoSeguro(f, ["RED", "red", "Red"]);
                var redStr = (r !== null) ? String(r).trim() : "Principal";
                if (redStr === "") redStr = "Principal";

                if (redesEncontradas.indexOf(redStr) === -1) {
                    redesEncontradas.push(redStr);
                }

                var cx = parseFloat(leerAtributoSeguro(f, ["COORDEX", "coordex", "X"]));
                var cy = parseFloat(leerAtributoSeguro(f, ["COORDEY", "coordey", "Y"]));
                var ez = parseFloat(leerAtributoSeguro(f, ["ELEVACION", "elevacion", "Z"]));

                var val = leerAtributoSeguro(f, ["VALVULA", "valvula"]);
                var valStr = (val !== null) ? String(val).trim() : "";

                var usr = leerAtributoSeguro(f, ["USUARIO", "usuario"]);
                var usrStr = (usr !== null) ? String(usr).trim() : "";

                if (!isNaN(cx) && !isNaN(cy) && !isNaN(ez)) {
                    ptsTemp.push({
                        punto: isNaN(pto) ? 0 : pto,
                        red: redStr,
                        valvula: valStr,
                        x: cx,
                        y: cy,
                        z: ez,
                        usuario: usrStr
                    });
                }
            }
            if (it) it.close();

            // Ordenar los ramales de forma natural (Principal primero, luego Ramal_1, Ramal_2...)
            var soloRamales = redesEncontradas.slice(1);
            soloRamales.sort(function(a, b) {
                return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
            });
            plugin.listaRedes = ["Principal"].concat(soloRamales);

            ptsTemp.sort(function(a, b) { return a.punto - b.punto; });
            var acumPorRed = {};
            var ultimoPorRed = {};
            var historialNuevo = [];

            for (var i = 0; i < ptsTemp.length; i++) {
                var item = ptsTemp[i];
                var rName = item.red;
                if (acumPorRed[rName] === undefined) {
                    acumPorRed[rName] = 0.0;
                } else {
                    var ant = ultimoPorRed[rName];
                    var dx = item.x - ant.x;
                    var dy = item.y - ant.y;
                    acumPorRed[rName] += Math.sqrt(dx * dx + dy * dy);
                }
                ultimoPorRed[rName] = item;
                item.distAcum = acumPorRed[rName];
                item.est = formatearEstacionamiento(item.distAcum);
                historialNuevo.push(item);
            }

            if (maxPunto > 0) {
                plugin.contadorPunto = maxPunto + 1;
            } else if (capaNodos.featureCount > 0) {
                plugin.contadorPunto = capaNodos.featureCount + 1;
            }

            plugin.historialPuntos = historialNuevo;
            plugin.datosProyectoCargados = true;
        } catch (e) {
            if (capaNodos.featureCount > 0 && plugin.contadorPunto === 1) {
                plugin.contadorPunto = capaNodos.featureCount + 1;
            }
        }
    }

    function formatearEstacionamiento(distancia) {
        var km = Math.floor(distancia / 1000);
        var m = (distancia % 1000).toFixed(1);
        var mStr = (distancia % 1000) < 10 ? "00" + m : ((distancia % 1000) < 100 ? "0" + m : "" + m);
        return km + "+" + mStr;
    }

    function obtenerPuntosPerfil() {
        var redObj = comboRedPerfil.currentText || "Principal";
        var pts = [];
        for (var i = 0; i < plugin.historialPuntos.length; i++) {
            if (plugin.historialPuntos[i].red === redObj) {
                pts.push(plugin.historialPuntos[i]);
            }
        }
        return pts;
    }

    function registrarNuevaRed(nombreRed) {
        var n = nombreRed.trim();
        if (n === "") return;
        var copia = plugin.listaRedes.slice();
        if (copia.indexOf(n) === -1) {
            copia.push(n);
            plugin.listaRedes = copia;
        }
        comboRed.currentIndex = plugin.listaRedes.indexOf(n);
    }

    function crearRamalConNumero() {
        var numTxt = txtNumRamal.text.trim();
        var num = parseInt(numTxt);

        if (isNaN(num) || num <= 0) {
            var maxNum = 0;
            for (var i = 0; i < plugin.listaRedes.length; i++) {
                var m = plugin.listaRedes[i].match(/^Ramal_(\d+)$/);
                if (m) {
                    var n = parseInt(m[1]);
                    if (n > maxNum) maxNum = n;
                }
            }
            num = maxNum + 1;
        }
        var nuevo = "Ramal_" + num;
        registrarNuevaRed(nuevo);
        txtNumRamal.text = "";
        mainWindow.displayToast("✅ Red activa: " + nuevo);
    }

    function crearSubRamalConNumero() {
        var actual = comboRed.currentText;
        if (actual === "Principal") {
            mainWindow.displayToast("⚠️ Primero selecciona un Ramal_X para crearle un subramal.");
            return;
        }
        var prefijo = actual + ".";
        var numTxt = txtNumRamal.text.trim();
        var num = parseInt(numTxt);

        if (isNaN(num) || num <= 0) {
            var maxSub = 0;
            for (var i = 0; i < plugin.listaRedes.length; i++) {
                var item = plugin.listaRedes[i];
                if (item.indexOf(prefijo) === 0) {
                    var resto = item.substring(prefijo.length);
                    if (/^\d+$/.test(resto)) {
                        var n = parseInt(resto);
                        if (n > maxSub) maxSub = n;
                    }
                }
            }
            num = maxSub + 1;
        }
        var nuevoSub = prefijo + num;
        registrarNuevaRed(nuevoSub);
        txtNumRamal.text = "";
        mainWindow.displayToast("✅ Subramal activo: " + nuevoSub);
    }

    // Centrar el mapa de QField sobre el punto seleccionado en el perfil y hacerlo destellar
    function centrarMapaEnPuntoPerfil() {
        var pts = obtenerPuntosPerfil();
        var idx = plugin.indicePuntoPerfil;
        if (pts.length === 0 || idx < 0 || idx >= pts.length) return;

        var p = pts[idx];
        var capaRef = obtenerCapaPorNombre("nodo") || obtenerCapaPorNombre("obra");
        if (!capaRef || !mapCanvas) return;

        var ptCapa = GeometryUtils.point(p.x, p.y);
        var ptCanvas = GeometryUtils.reprojectPoint(ptCapa, capaRef.crs, mapCanvas.mapSettings.destinationCrs);
        mapCanvas.mapSettings.setCenter(ptCanvas);

        // Si el localizador nativo de QField está disponible, resaltar el punto en pantalla
        if (coordinateLocator && coordinateLocator.flashGeometry) {
            var geomWkt = GeometryUtils.createGeometryFromWkt("POINT(" + p.x + " " + p.y + ")");
            coordinateLocator.flashGeometry(geomWkt, capaRef.crs);
        }
        mainWindow.displayToast("🔍 Mapa centrado en Pto #" + p.punto);
    }

    // 1. Botón en barra de complementos
    QfToolButton {
        id: btnPlugin
        bgcolor: Theme.darkGray
        round: true
        onClicked: {
            sincronizarDesdeCapaNodos();
            panelCaptura.visible = !panelCaptura.visible;
        }

        Canvas {
            anchors.fill: parent
            anchors.margins: 10
            onPaint: {
                var ctx = getContext("2d");
                ctx.reset();
                ctx.strokeStyle = "#FFFFFF";
                ctx.lineWidth = 2.2;

                var w = width, h = height, cy = h * 0.62;
                ctx.beginPath();
                ctx.moveTo(w * 0.15, cy - h * 0.22);
                ctx.lineTo(w * 0.85, cy + h * 0.22);
                ctx.lineTo(w * 0.85, cy - h * 0.22);
                ctx.lineTo(w * 0.15, cy + h * 0.22);
                ctx.closePath();
                ctx.stroke();

                ctx.beginPath();
                ctx.moveTo(w * 0.5, cy);
                ctx.lineTo(w * 0.5, h * 0.20);
                ctx.moveTo(w * 0.25, h * 0.20);
                ctx.lineTo(w * 0.75, h * 0.20);
                ctx.stroke();
            }
        }
    }

    // 2. Banner de Elevación + Precisión GPS (Se puede arrastrar con el dedo si tapa algo)
    Rectangle {
        id: barraElevacion
        parent: mainWindow.contentItem
        x: (parent.width - width) / 2
        y: 48
        width: 280
        height: 40
        radius: 8
        color: "#D9111111"
        border.color: "#33a02c"
        border.width: 2
        z: 9999

        MouseArea {
            anchors.fill: parent
            drag.target: barraElevacion
            drag.axis: Drag.XAndYAxis
            drag.minimumX: 0
            drag.maximumX: parent.parent.width - barraElevacion.width
            drag.minimumY: 36
            drag.maximumY: parent.parent.height - 100
        }

        Text {
            anchors.centerIn: parent
            color: "#00FFFF"
            font.pixelSize: 15
            font.bold: true
            text: {
                if (positionSource && positionSource.active && positionSource.positionInformation) {
                    var info = positionSource.positionInformation;
                    var z = info.elevation;
                    var hacc = info.hacc;
                    var txtZ = !isNaN(z) ? "⛰️ Z: " + z.toFixed(1) + " m" : "⛰️ Z: Sin 3D";
                    var txtAcc = (!isNaN(hacc) && hacc > 0) ? " (±" + hacc.toFixed(1) + "m)" : "";
                    return txtZ + txtAcc;
                }
                return "⚠️ GPS Inactivo (Modo Mira Manual)";
            }
        }
    }

    // 3. Panel Flotante elevado (bottomMargin: 135) para dejar libres los botones GPS y '+' de QField
    Rectangle {
        id: panelCaptura
        parent: mainWindow.contentItem
        visible: false
        width: Math.min(parent.width * 0.94, 410)
        height: colPrincipal.implicitHeight + 20
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.leftMargin: 10
        anchors.bottomMargin: 135
        radius: 12
        color: "#EB1E1E1E"
        border.color: "#1f78b4"
        border.width: 2
        z: 10000

        ColumnLayout {
            id: colPrincipal
            anchors.fill: parent
            anchors.margins: 10
            spacing: 6

            // Barra de título con modo compacto (Minimizar), Perfil y Cerrar
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text {
                    text: "Tuberías (" + comboRed.currentText + ")"
                    color: "white"
                    font.pixelSize: 14
                    font.bold: true
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                }
                Button {
                    text: plugin.panelMinimizado ? "🔼 Expandir" : "➖"
                    Layout.preferredWidth: plugin.panelMinimizado ? 85 : 34
                    onClicked: {
                        plugin.panelMinimizado = !plugin.panelMinimizado;
                        if (plugin.panelMinimizado) contenedorPerfil.visible = false;
                    }
                }
                Button {
                    visible: !plugin.panelMinimizado
                    text: contenedorPerfil.visible ? "Ocultar" : "📈 Perfil"
                    onClicked: {
                        sincronizarDesdeCapaNodos();
                        contenedorPerfil.visible = !contenedorPerfil.visible;
                        if (contenedorPerfil.visible) {
                            var pts = obtenerPuntosPerfil();
                            plugin.indicePuntoPerfil = pts.length - 1;
                            canvasPerfil.requestPaint();
                        }
                    }
                }
                Button {
                    text: "X"
                    Layout.preferredWidth: 34
                    onClicked: panelCaptura.visible = false
                }
            }

            // Selector de modo de captura: Mira de QField (Snapping/Paneo) vs GPS directo
            RowLayout {
                visible: !plugin.panelMinimizado
                Layout.fillWidth: true
                spacing: 6
                Text { text: "Captura:"; color: "#AAAAAA"; font.pixelSize: 12 }
                Button {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 30
                    text: plugin.usarMiraQField ? "🎯 Usando Mira QField (Snap/Mapa)" : "📡 Usando GPS Directo"
                    background: Rectangle {
                        color: plugin.usarMiraQField ? "#1f78b4" : "#444444"
                        radius: 4
                    }
                    contentItem: Text {
                        text: parent.text
                        color: "white"
                        font.pixelSize: 11
                        font.bold: true
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    onClicked: plugin.usarMiraQField = !plugin.usarMiraQField
                }
            }

            // Controles de formulario (se ocultan al minimizar el panel para despejar el mapa)
            ColumnLayout {
                visible: !plugin.panelMinimizado
                Layout.fillWidth: true
                spacing: 6

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    Text { text: "RED:"; color: "#CCCCCC"; font.bold: true; Layout.preferredWidth: 42 }

                    ComboBox {
                        id: comboRed
                        Layout.fillWidth: true
                        model: plugin.listaRedes
                    }

                    TextField {
                        id: txtNumRamal
                        enabled: !plugin.esPrincipal
                        opacity: enabled ? 1.0 : 0.35
                        Layout.preferredWidth: 40
                        placeholderText: "N°"
                        horizontalAlignment: TextInput.AlignHCenter
                        inputMethodHints: Qt.ImhDigitsOnly
                        color: "white"
                        background: Rectangle {
                            color: "#333333"
                            radius: 4
                            border.color: parent.enabled ? "#1f78b4" : "#444444"
                        }
                    }

                    Button {
                        text: "+Ramal"
                        onClicked: crearRamalConNumero()
                    }

                    Button {
                        text: "+Sub"
                        enabled: !plugin.esPrincipal
                        opacity: enabled ? 1.0 : 0.35
                        onClicked: crearSubRamalConNumero()
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    Text { text: "VALVULA:"; color: "#CCCCCC"; font.bold: true; Layout.preferredWidth: 68 }
                    ComboBox {
                        id: comboElemento
                        Layout.fillWidth: true
                        model: catalogoValvulas
                        textRole: "etiqueta"
                        valueRole: "codigo"
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    Text { text: "USUARIO:"; color: "#fdbf6f"; font.bold: true; Layout.preferredWidth: 68 }
                    TextField {
                        id: txtUsuario
                        Layout.fillWidth: true
                        placeholderText: "Nombre del usuario (opcional)"
                        color: "white"
                        background: Rectangle {
                            color: "#333333"
                            radius: 4
                            border.color: "#555555"
                        }
                    }
                }
            }

            // 4. Visor de Perfil Longitudinal
            Rectangle {
                id: contenedorPerfil
                visible: false
                Layout.fillWidth: true
                Layout.preferredHeight: 250
                color: "#141414"
                radius: 8
                border.color: "#444444"
                border.width: 1

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 6
                    spacing: 4

                    RowLayout {
                        Layout.fillWidth: true
                        Text { text: "Perfil:"; color: "#00FFFF"; font.bold: true; font.pixelSize: 12 }
                        ComboBox {
                            id: comboRedPerfil
                            Layout.fillWidth: true
                            model: plugin.listaRedes
                            currentIndex: 0
                            onCurrentTextChanged: {
                                var pts = obtenerPuntosPerfil();
                                plugin.indicePuntoPerfil = pts.length - 1;
                                canvasPerfil.requestPaint();
                            }
                        }
                        Button {
                            text: "🔍 Mapa"
                            ToolTip.visible: down
                            ToolTip.text: "Centrar mapa en el punto seleccionado"
                            onClicked: centrarMapaEnPuntoPerfil()
                        }
                    }

                    Canvas {
                        id: canvasPerfil
                        Layout.fillWidth: true
                        Layout.fillHeight: true

                        onPaint: {
                            var ctx = getContext("2d");
                            ctx.reset();
                            ctx.clearRect(0, 0, width, height);

                            var pts = obtenerPuntosPerfil();
                            var redMostrada = comboRedPerfil.currentText || "Principal";

                            var gpsActivo = false, gpsZ = 0.0, gpsDist = 0.0;
                            var capaRef = obtenerCapaPorNombre("nodo") || obtenerCapaPorNombre("obra");

                            if (positionSource && positionSource.active && positionSource.positionInformation && capaRef) {
                                var pos = positionSource.positionInformation;
                                if (!isNaN(pos.elevation) && !isNaN(pos.longitude)) {
                                    gpsActivo = true;
                                    gpsZ = pos.elevation;
                                    var pWgs = GeometryUtils.point(pos.longitude, pos.latitude);
                                    var crsWgs = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326");
                                    var pMap = GeometryUtils.reprojectPoint(pWgs, crsWgs, capaRef.crs);

                                    if (pts.length > 0) {
                                        var ult = pts[pts.length - 1];
                                        var dx = pMap.x - ult.x;
                                        var dy = pMap.y - ult.y;
                                        gpsDist = ult.distAcum + Math.sqrt(dx * dx + dy * dy);
                                    }
                                }
                            }

                            if (pts.length === 0) {
                                ctx.fillStyle = "#AAAAAA";
                                ctx.font = "12px sans-serif";
                                ctx.fillText("Sin puntos en '" + redMostrada + "'.", 10, height / 2);
                                return;
                            }

                            var minZ = pts[0].z, maxZ = pts[0].z;
                            var maxDist = pts[pts.length - 1].distAcum;

                            for (var i = 1; i < pts.length; i++) {
                                if (pts[i].z < minZ) minZ = pts[i].z;
                                if (pts[i].z > maxZ) maxZ = pts[i].z;
                            }
                            if (gpsActivo) {
                                if (gpsZ < minZ) minZ = gpsZ;
                                if (gpsZ > maxZ) maxZ = gpsZ;
                                if (gpsDist > maxDist) maxDist = gpsDist;
                            }
                            if (Math.abs(maxZ - minZ) < 2.0) { maxZ += 1.0; minZ -= 1.0; }
                            if (maxDist <= 0.1) maxDist = 10.0;

                            var padL = 40, padR = 14, padT = 16, padB = 18;
                            var w = width - padL - padR;
                            var h = height - padT - padB;

                            ctx.strokeStyle = "#444444";
                            ctx.lineWidth = 1;
                            ctx.beginPath();
                            ctx.moveTo(padL, padT);
                            ctx.lineTo(padL, padT + h);
                            ctx.lineTo(padL + w, padT + h);
                            ctx.stroke();

                            ctx.fillStyle = "#CCCCCC";
                            ctx.font = "10px sans-serif";
                            ctx.fillText(maxZ.toFixed(0) + "m", 2, padT + 8);
                            ctx.fillText(minZ.toFixed(0) + "m", 2, padT + h);
                            ctx.fillText("0+000", padL, height - 3);
                            ctx.fillText(formatearEstacionamiento(maxDist), padL + w - 45, height - 3);

                            ctx.strokeStyle = "#33a02c";
                            ctx.lineWidth = 2.5;
                            ctx.beginPath();
                            for (var k = 0; k < pts.length; k++) {
                                var px = padL + (pts[k].distAcum / maxDist) * w;
                                var py = padT + h - ((pts[k].z - minZ) / (maxZ - minZ)) * h;
                                if (k === 0) ctx.moveTo(px, py);
                                else ctx.lineTo(px, py);
                            }
                            ctx.stroke();

                            if (gpsActivo && pts.length > 0) {
                                var ultPx = padL + (pts[pts.length - 1].distAcum / maxDist) * w;
                                var ultPy = padT + h - ((pts[pts.length - 1].z - minZ) / (maxZ - minZ)) * h;
                                var gpsPx = padL + (gpsDist / maxDist) * w;
                                var gpsPy = padT + h - ((gpsZ - minZ) / (maxZ - minZ)) * h;

                                ctx.strokeStyle = "#00FFFF";
                                ctx.lineWidth = 1.5;
                                ctx.setLineDash([4, 4]);
                                ctx.beginPath();
                                ctx.moveTo(ultPx, ultPy);
                                ctx.lineTo(gpsPx, gpsPy);
                                ctx.stroke();
                                ctx.setLineDash([]);

                                ctx.fillStyle = "#00FFFF";
                                ctx.beginPath();
                                ctx.arc(gpsPx, gpsPy, 5, 0, 2 * Math.PI);
                                ctx.fill();
                                ctx.fillText("Tú", gpsPx - 8, gpsPy - 8);
                            }

                            for (var m = 0; m < pts.length; m++) {
                                var nx = padL + (pts[m].distAcum / maxDist) * w;
                                var ny = padT + h - ((pts[m].z - minZ) / (maxZ - minZ)) * h;

                                if (m === plugin.indicePuntoPerfil) {
                                    ctx.strokeStyle = "#FFFF00";
                                    ctx.lineWidth = 1;
                                    ctx.beginPath();
                                    ctx.moveTo(nx, padT);
                                    ctx.lineTo(nx, padT + h);
                                    ctx.stroke();

                                    ctx.fillStyle = "#FFFF00";
                                    ctx.beginPath();
                                    ctx.arc(nx, ny, 6.5, 0, 2 * Math.PI);
                                    ctx.fill();
                                }

                                ctx.beginPath();
                                if (pts[m].valvula !== "") {
                                    ctx.fillStyle = "#e31a1c";
                                    ctx.arc(nx, ny, 4, 0, 2 * Math.PI);
                                    ctx.fill();

                                    ctx.fillStyle = "#fdbf6f";
                                    ctx.font = "bold 9px sans-serif";
                                    ctx.fillText(pts[m].valvula, nx - 7, ny - 8);
                                } else {
                                    ctx.fillStyle = "#FFFFFF";
                                    ctx.arc(nx, ny, 2.5, 0, 2 * Math.PI);
                                    ctx.fill();
                                }
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 4

                        Button {
                            text: "◀ Ant."
                            Layout.preferredWidth: 62
                            onClicked: {
                                var pts = obtenerPuntosPerfil();
                                if (pts.length === 0) return;
                                if (plugin.indicePuntoPerfil > 0) plugin.indicePuntoPerfil -= 1;
                                else plugin.indicePuntoPerfil = 0;
                                canvasPerfil.requestPaint();
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            height: 36
                            color: "#222222"
                            radius: 4
                            border.color: "#FFFF00"
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                color: "white"
                                font.pixelSize: 10
                                font.bold: true
                                horizontalAlignment: Text.AlignHCenter
                                text: {
                                    var pts = obtenerPuntosPerfil();
                                    var idx = plugin.indicePuntoPerfil;
                                    if (pts.length === 0 || idx < 0 || idx >= pts.length) return "Sin selección";
                                    var p = pts[idx];
                                    var tipo = p.valvula === "" ? "NODO" : p.valvula;
                                    var usr = p.usuario !== "" ? " | " + p.usuario : "";
                                    return "Pto #" + p.punto + " [" + tipo + "] | " + p.est + "\nZ: " + p.z.toFixed(1) + " m" + usr;
                                }
                            }
                        }

                        Button {
                            text: "Sig. ▶"
                            Layout.preferredWidth: 62
                            onClicked: {
                                var pts = obtenerPuntosPerfil();
                                if (pts.length === 0) return;
                                if (plugin.indicePuntoPerfil < pts.length - 1) plugin.indicePuntoPerfil += 1;
                                else plugin.indicePuntoPerfil = pts.length - 1;
                                canvasPerfil.requestPaint();
                            }
                        }
                    }
                }
            }

            // Botón de Registro (Siempre disponible incluso con el panel minimizado)
            Button {
                Layout.fillWidth: true
                Layout.preferredHeight: 44
                text: "📍 REGISTRAR #" + plugin.contadorPunto + " [" + catalogoValvulas.get(comboElemento.currentIndex).codigo + "]"
                font.bold: true
                font.pixelSize: 14
                background: Rectangle {
                    color: parent.down ? "#23701e" : "#33a02c"
                    radius: 8
                }
                contentItem: Text {
                    text: parent.text
                    color: "white"
                    font: parent.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                onClicked: registrarPuntoEnCapas()
            }
        }
    }

    function insertarEnCapa(capa, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, esRequeridoRed, faltantesOut) {
        var wkt = "POINT(" + xActual + " " + yActual + ")";
        var geom = GeometryUtils.createGeometryFromWkt(wkt);
        var feature = FeatureUtils.createBlankFeature(capa.fields, geom);
        var campos = capa.fields.names;

        function asignar(nombreCol, valor, avisarSiFalta) {
            var existe = false;
            for (var c = 0; c < campos.length; c++) {
                if (campos[c].toUpperCase() === nombreCol.toUpperCase()) {
                    feature.setAttribute(c, valor);
                    existe = true;
                    break;
                }
            }
            if (!existe && avisarSiFalta && faltantesOut.indexOf(nombreCol) === -1) {
                faltantesOut.push(nombreCol + " en " + capa.name);
            }
        }

        asignar("PUNTO", plugin.contadorPunto, true);
        asignar("COORDEX", Math.round(xActual), true);
        asignar("COORDEY", Math.round(yActual), true);
        asignar("ELEVACION", Math.round(elev * 100) / 100, true);
        asignar("VALVULA", valorValvula, true);
        asignar("RED", redSeleccionada, esRequeridoRed);
        asignar("USUARIO", textoUsuario, false);
        asignar("ID_TOMA", 0, false);

        return LayerUtils.addFeature(capa, feature);
    }

    function registrarPuntoEnCapas() {
        var capaNodos = obtenerCapaPorNombre("nodo");
        var capaObras = obtenerCapaPorNombre("obra");
        var capaActiva = (dashBoard && dashBoard.activeLayer && dashBoard.activeLayer.geometryType() === Qgis.GeometryType.Point) ? dashBoard.activeLayer : null;

        var capaRef = capaNodos || capaObras || capaActiva;
        if (!capaRef) {
            mainWindow.displayToast("⚠️ No se encontró la capa Nodos ni ObrasCiviles en el proyecto.");
            return;
        }

        var xActual = 0.0;
        var yActual = 0.0;
        var elev = 0.0;

        // Obtener elevación del GPS si está activo
        if (positionSource && positionSource.active && positionSource.positionInformation) {
            var zGps = positionSource.positionInformation.elevation;
            if (!isNaN(zGps)) elev = zGps;
        }

        // MODO 1: Usar Mira Nativa de QField (Soporta Snapping, Paneo manual o Centro GPS)
        if (plugin.usarMiraQField && mapCanvas) {
            var ptOrigen = null;
            var crsOrigen = mapCanvas.mapSettings.destinationCrs;

            if (coordinateLocator && coordinateLocator.currentCoordinate !== undefined && !isNaN(coordinateLocator.currentCoordinate.x)) {
                ptOrigen = coordinateLocator.currentCoordinate;
                // Si el imán (snapping) atrapó un punto con Z, usar esa Z si no hay GPS
                if (elev === 0.0 && !isNaN(ptOrigen.z)) elev = ptOrigen.z;
            } else {
                ptOrigen = mapCanvas.mapSettings.center;
            }

            var ptReproyectado = GeometryUtils.reprojectPoint(ptOrigen, crsOrigen, capaRef.crs);
            xActual = ptReproyectado.x;
            yActual = ptReproyectado.y;
        } else {
            // MODO 2: GPS Directo estricto
            if (!positionSource || !positionSource.active || !positionSource.positionInformation) {
                mainWindow.displayToast("⚠️ El GPS no está activo. Actívalo o cambia al modo '🎯 Mira QField'.");
                return;
            }
            var pos = positionSource.positionInformation;
            var puntoWgs84 = GeometryUtils.point(pos.longitude, pos.latitude);
            var crsWgs84 = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326");
            var puntoTransformado = GeometryUtils.reprojectPoint(puntoWgs84, crsWgs84, capaRef.crs);
            xActual = puntoTransformado.x;
            yActual = puntoTransformado.y;
        }

        var redSeleccionada = comboRed.currentText;
        var codigoSeleccionado = catalogoValvulas.get(comboElemento.currentIndex).codigo;
        var valorValvula = (codigoSeleccionado === "NODO") ? "" : codigoSeleccionado;
        var textoUsuario = txtUsuario.text.trim();

        var distAcumulada = 0.0;
        for (var i = plugin.historialPuntos.length - 1; i >= 0; i--) {
            if (plugin.historialPuntos[i].red === redSeleccionada) {
                var dx = xActual - plugin.historialPuntos[i].x;
                var dy = yActual - plugin.historialPuntos[i].y;
                distAcumulada = plugin.historialPuntos[i].distAcum + Math.sqrt(dx * dx + dy * dy);
                break;
            }
        }
        var estTexto = formatearEstacionamiento(distAcumulada);

        var faltantes = [];
        var guardadoNodos = false;
        var guardadoObras = false;

        if (capaNodos) {
            var cantAntes = capaObras ? capaObras.featureCount : -1;
            guardadoNodos = insertarEnCapa(capaNodos, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, true, faltantes);

            if (valorValvula !== "" && capaObras && capaObras !== capaOodos) {
                if (capaObras.featureCount === cantAntes) {
                    guardadoObras = insertarEnCapa(capaObras, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, false, faltantes);
                } else {
                    guardadoObras = true;
                }
            }
        } else if (capaObras) {
            guardadoObras = insertarEnCapa(capaObras, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, false, faltantes);
        } else if (capaActiva) {
            guardadoNodos = insertarEnCapa(capaActiva, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, true, faltantes);
        }

        if (guardadoNodos || guardadoObras) {
            if (mapCanvas) mapCanvas.refresh();

            // Destello visual en el mapa donde se guardó el punto
            if (coordinateLocator && coordinateLocator.flashGeometry) {
                var geomFlash = GeometryUtils.createGeometryFromWkt("POINT(" + xActual + " " + yActual + ")");
                coordinateLocator.flashGeometry(geomFlash, capaRef.crs);
            }

            var nuevoHistorial = plugin.historialPuntos.slice();
            nuevoHistorial.push({
                punto: plugin.contadorPunto,
                red: redSeleccionada,
                valvula: valorValvula,
                x: xActual,
                y: yActual,
                z: elev,
                distAcum: distAcumulada,
                est: estTexto,
                usuario: textoUsuario
            });
            plugin.historialPuntos = nuevoHistorial;

            var ptsPerfil = obtenerPuntosPerfil();
            plugin.indicePuntoPerfil = ptsPerfil.length - 1;
            if (contenedorPerfil.visible) {
                canvasPerfil.requestPaint();
            }

            var etq = valorValvula === "" ? "NODO" : valorValvula;
            var modoTxt = plugin.usarMiraQField ? "🎯" : "📡";
            if (faltantes.length > 0) {
                mainWindow.displayToast("⚠️ " + modoTxt + " #" + plugin.contadorPunto + " [" + etq + "]. Omitidos: " + faltantes.join(", "));
            } else {
                mainWindow.displayToast("✅ " + modoTxt + " #" + plugin.contadorPunto + " [" + etq + "] en " + redSeleccionada + " (Z: " + elev.toFixed(1) + "m)");
            }

            plugin.contadorPunto += 1;
            comboElemento.currentIndex = 0;
            txtUsuario.text = "";
        } else {
            mainWindow.displayToast("❌ No se pudo guardar el punto. Verifica que las capas sean editables en QField.");
        }
    }
}