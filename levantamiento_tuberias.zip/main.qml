import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qgis
import org.qfield
import Theme

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var positionSource: iface.findItemByObjectName('positionSource')
    property var dashBoard: iface.findItemByObjectName('dashBoard')
    property var mapCanvas: iface.mapCanvas()

    property int contadorPunto: 1
    property var historialPuntos: []
    property var listaRedes: ["Principal", "Ramal"]
    property int indicePuntoPerfil: -1
    property bool datosProyectoCargados: false

    // Deshabilita botones de ramal cuando está seleccionado "Principal"
    property bool esPrincipal: comboRed.currentText === "Principal"

    ListModel {
        id: catalogoValvulas
        ListElement { codigo: "NODO"; etiqueta: "NODO - Punto Normal (Vacío)" }
        ListElement { codigo: "VA";   etiqueta: "VA - Válvula de Aire" }
        ListElement { codigo: "TQ";   etiqueta: "TQ - Tanque Quiebragradiente" }
        ListElement { codigo: "FT";   etiqueta: "FT - Filtrado" }
        ListElement { codigo: "VT";   etiqueta: "VT - Toma Parcelaria" }
        ListElement { codigo: "AB";   etiqueta: "AB - Abrevadero" }
        ListElement { codigo: "VCL";  etiqueta: "VCL - Válvula Compuerta" }
        ListElement { codigo: "VM";   etiqueta: "VM - Válvula Mariposa" }
        ListElement { codigo: "VL";   etiqueta: "VL - Válvula Limpieza" }
        ListElement { codigo: "VR";   etiqueta: "VR - Válvula Reguladora" }
        ListElement { codigo: "VS";   etiqueta: "VS - Válvula Sostenedora" }
        ListElement { codigo: "VAL";  etiqueta: "VAL - Válvula Alivio" }
        ListElement { codigo: "PT";   etiqueta: "PT - Puente Tubo" }
        ListElement { codigo: "PA";   etiqueta: "PA - Paso Aéreo" }
        ListElement { codigo: "D";    etiqueta: "D - Desarenador" }
        ListElement { codigo: "T";    etiqueta: "T - Presa / Captación" }
        ListElement { codigo: "R";    etiqueta: "R - Reservorio" }
        ListElement { codigo: "MD";   etiqueta: "MD - Medidor de Caudal" }
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(btnPlugin)
    }

    Connections {
        target: positionSource
        function onPositionInformationChanged() {
            if (panelCaptura.visible && contenedorPerfil.visible) {
                canvasPerfil.requestPaint()
            }
        }
    }

    // Buscar específicamente la capa Nodos y la capa ObrasCiviles en el proyecto
    function obtenerCapaPorNombre(palabraClave) {
        var capas = ProjectUtils.mapLayers(qgisProject);
        var clave = palabraClave.toLowerCase();
        for (var id in capas) {
            var l = capas[id];
            if (l && l.name && l.name.toLowerCase().indexOf(clave) !== -1) {
                return l;
            }
        }
        return null;
    }

    // Cargar los valores de RED y puntos existentes desde la capa Nodos al abrir el panel
    function sincronizarDesdeCapaNodos() {
        var capaNodos = obtenerCapaPorNombre("nodos");
        if (!capaNodos) capaNodos = obtenerCapaPorNombre("obrasciviles");
        if (!capaNodos) return;

        try {
            var it = LayerUtils.createFeatureIteratorFromExpression(capaNodos, "TRUE");
            var redesEncontradas = ["Principal", "Ramal"];
            var ptsTemp = [];
            var maxPunto = 0;

            while (it && it.hasNext()) {
                var f = it.next();
                var pto = parseInt(f.attribute("PUNTO"));
                if (!isNaN(pto) && pto > maxPunto) maxPunto = pto;

                var r = f.attribute("RED");
                var redStr = (r !== undefined && r !== null) ? String(r).trim() : "";
                if (redStr !== "" && redStr.toLowerCase() !== "null") {
                    if (redesEncontradas.indexOf(redStr) === -1) {
                        redesEncontradas.push(redStr);
                    }
                    var cx = parseFloat(f.attribute("COORDEX"));
                    var cy = parseFloat(f.attribute("COORDEY"));
                    var ez = parseFloat(f.attribute("ELEVACION"));
                    var val = f.attribute("VALVULA");
                    var valStr = (val !== undefined && val !== null && String(val).toLowerCase() !== "null") ? String(val).trim() : "";
                    var usr = f.attribute("USUARIO");
                    var usrStr = (usr !== undefined && usr !== null && String(usr).toLowerCase() !== "null") ? String(usr).trim() : "";

                    if (!isNaN(cx) && !isNaN(cy) && !isNaN(ez)) {
                        ptsTemp.push({
                            punto: isNaN(pto) ? 0 : pto,
                            red: redStr,
                            valvula: valStr,
                            x: cx,
                            y: cy,
                            z: ez,
                            usuario: usrStr
                        });
                    }
                }
            }
            if (it) it.close();

            // Ordenar por número de PUNTO y calcular distancias acumuladas por cada RED
            ptsTemp.sort(function(a, b) { return a.punto - b.punto; });
            var acumPorRed = {};
            var ultimoPorRed = {};
            var historialNuevo = [];

            for (var i = 0; i < ptsTemp.length; i++) {
                var item = ptsTemp[i];
                var rName = item.red;
                if (acumPorRed[rName] === undefined) {
                    acumPorRed[rName] = 0.0;
                } else {
                    var ant = ultimoPorRed[rName];
                    var dx = item.x - ant.x;
                    var dy = item.y - ant.y;
                    acumPorRed[rName] += Math.sqrt(dx * dx + dy * dy);
                }
                ultimoPorRed[rName] = item;
                item.distAcum = acumPorRed[rName];
                item.est = formatearEstacionamiento(item.distAcum);
                historialNuevo.push(item);
            }

            if (maxPunto > 0) {
                plugin.contadorPunto = maxPunto + 1;
            } else if (capaNodos.featureCount > 0) {
                plugin.contadorPunto = capaNodos.featureCount + 1;
            }

            plugin.listaRedes = redesEncontradas;
            if (historialNuevo.length > 0) {
                plugin.historialPuntos = historialNuevo;
            }
            plugin.datosProyectoCargados = true;
        } catch (e) {
            // Si la versión de QField no soporta iterador directo, usa featureCount
            if (capaNodos.featureCount > 0 && plugin.contadorPunto === 1) {
                plugin.contadorPunto = capaNodos.featureCount + 1;
            }
        }
    }

    function formatearEstacionamiento(distancia) {
        var km = Math.floor(distancia / 1000);
        var m = (distancia % 1000).toFixed(1);
        var mStr = (distancia % 1000) < 10 ? "00" + m : ((distancia % 1000) < 100 ? "0" + m : "" + m);
        return km + "+" + mStr;
    }

    function obtenerPuntosPerfil() {
        var redObj = comboRedPerfil.currentText || "Principal";
        var pts = [];
        for (var i = 0; i < plugin.historialPuntos.length; i++) {
            if (plugin.historialPuntos[i].red === redObj) {
                pts.push(plugin.historialPuntos[i]);
            }
        }
        return pts;
    }

    function registrarNuevaRed(nombreRed) {
        var n = nombreRed.trim();
        if (n === "") return;
        var copia = plugin.listaRedes.slice();
        if (copia.indexOf(n) === -1) {
            copia.push(n);
            plugin.listaRedes = copia;
        }
        comboRed.currentIndex = plugin.listaRedes.indexOf(n);
    }

    function crearRamalConNumero() {
        var numTxt = txtNumRamal.text.trim();
        var num = parseInt(numTxt);

        if (isNaN(num) || num <= 0) {
            var maxNum = 0;
            for (var i = 0; i < plugin.listaRedes.length; i++) {
                var m = plugin.listaRedes[i].match(/^Ramal_(\d+)$/);
                if (m) {
                    var n = parseInt(m[1]);
                    if (n > maxNum) maxNum = n;
                }
            }
            num = maxNum + 1;
        }
        var nuevo = "Ramal_" + num;
        registrarNuevaRed(nuevo);
        txtNumRamal.text = "";
        mainWindow.displayToast("✅ Red activa: " + nuevo);
    }

    function crearSubRamalConNumero() {
        var actual = comboRed.currentText;
        if (actual === "Principal" || actual === "Ramal") {
            mainWindow.displayToast("⚠️ Primero selecciona un Ramal_X para crearle un subramal.");
            return;
        }
        var prefijo = actual + ".";
        var numTxt = txtNumRamal.text.trim();
        var num = parseInt(numTxt);

        if (isNaN(num) || num <= 0) {
            var maxSub = 0;
            for (var i = 0; i < plugin.listaRedes.length; i++) {
                var item = plugin.listaRedes[i];
                if (item.indexOf(prefijo) === 0) {
                    var resto = item.substring(prefijo.length);
                    if (/^\d+$/.test(resto)) {
                        var n = parseInt(resto);
                        if (n > maxSub) maxSub = n;
                    }
                }
            }
            num = maxSub + 1;
        }
        var nuevoSub = prefijo + num;
        registrarNuevaRed(nuevoSub);
        txtNumRamal.text = "";
        mainWindow.displayToast("✅ Subramal activo: " + nuevoSub);
    }

    // 1. Botón circular con ícono blanco de Válvula
    QfToolButton {
        id: btnPlugin
        bgcolor: Theme.darkGray
        round: true
        onClicked: {
            if (!plugin.datosProyectoCargados) {
                sincronizarDesdeCapaNodos();
            }
            panelCaptura.visible = !panelCaptura.visible;
        }

        Canvas {
            anchors.fill: parent
            anchors.margins: 10
            onPaint: {
                var ctx = getContext("2d");
                ctx.reset();
                ctx.strokeStyle = "#FFFFFF";
                ctx.lineWidth = 2.2;

                var w = width, h = height, cy = h * 0.62;
                ctx.beginPath();
                ctx.moveTo(w * 0.15, cy - h * 0.22);
                ctx.lineTo(w * 0.85, cy + h * 0.22);
                ctx.lineTo(w * 0.85, cy - h * 0.22);
                ctx.lineTo(w * 0.15, cy + h * 0.22);
                ctx.closePath();
                ctx.stroke();

                ctx.beginPath();
                ctx.moveTo(w * 0.5, cy);
                ctx.lineTo(w * 0.5, h * 0.20);
                ctx.moveTo(w * 0.25, h * 0.20);
                ctx.lineTo(w * 0.75, h * 0.20);
                ctx.stroke();
            }
        }
    }

    // 2. Banner Superior de Elevación (Debajo de la barra de estado del teléfono)
    Rectangle {
        id: barraElevacion
        parent: mainWindow.contentItem
        anchors.top: parent.top
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.topMargin: 48
        width: 250
        height: 40
        radius: 8
        color: "#D9111111"
        border.color: "#33a02c"
        border.width: 2
        z: 9999

        Text {
            anchors.centerIn: parent
            color: "#00FFFF"
            font.pixelSize: 17
            font.bold: true
            text: {
                if (positionSource && positionSource.active && positionSource.positionInformation) {
                    var z = positionSource.positionInformation.elevation;
                    return !isNaN(z) ? "⛰️ Z: " + z.toFixed(1) + " m.s.n.m." : "⛰️ Z: Sin señal 3D";
                }
                return "⚠️ GPS Inactivo";
            }
        }
    }

    // 3. Panel Principal (Arriba de los botones de navegación de Android)
    Rectangle {
        id: panelCaptura
        parent: mainWindow.contentItem
        visible: false
        width: Math.min(parent.width * 0.96, 420)
        height: colPrincipal.implicitHeight + 24
        anchors.bottom: parent.bottom
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottomMargin: 58
        radius: 12
        color: "#F21E1E1E"
        border.color: "#1f78b4"
        border.width: 2
        z: 10000

        ColumnLayout {
            id: colPrincipal
            anchors.fill: parent
            anchors.margins: 12
            spacing: 8

            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: "Levantamiento de Tubería"
                    color: "white"
                    font.pixelSize: 15
                    font.bold: true
                    Layout.fillWidth: true
                }
                Button {
                    text: contenedorPerfil.visible ? "Ocultar Perfil" : "📈 Ver Perfil"
                    onClicked: {
                        contenedorPerfil.visible = !contenedorPerfil.visible
                        if (contenedorPerfil.visible) {
                            var pts = obtenerPuntosPerfil();
                            plugin.indicePuntoPerfil = pts.length - 1;
                            canvasPerfil.requestPaint();
                        }
                    }
                }
                Button {
                    text: "X"
                    Layout.preferredWidth: 36
                    onClicked: panelCaptura.visible = false
                }
            }

            // Selector de RED (Alimentado por la capa Nodos)
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "RED:"; color: "#CCCCCC"; font.bold: true; Layout.preferredWidth: 42 }

                ComboBox {
                    id: comboRed
                    Layout.fillWidth: true
                    model: plugin.listaRedes
                }

                TextField {
                    id: txtNumRamal
                    enabled: !plugin.esPrincipal
                    opacity: enabled ? 1.0 : 0.35
                    Layout.preferredWidth: 42
                    placeholderText: "N°"
                    horizontalAlignment: TextInput.AlignHCenter
                    inputMethodHints: Qt.ImhDigitsOnly
                    color: "white"
                    background: Rectangle {
                        color: "#333333"
                        radius: 4
                        border.color: parent.enabled ? "#1f78b4" : "#444444"
                    }
                }

                Button {
                    text: "+Ramal"
                    enabled: !plugin.esPrincipal
                    opacity: enabled ? 1.0 : 0.35
                    onClicked: crearRamalConNumero()
                }

                Button {
                    text: "+Sub"
                    enabled: !plugin.esPrincipal && comboRed.currentText !== "Ramal"
                    opacity: enabled ? 1.0 : 0.35
                    onClicked: crearSubRamalConNumero()
                }
            }

            // Selector de VALVULA (ObrasCiviles + Nodos)
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "VALVULA:"; color: "#CCCCCC"; font.bold: true; Layout.preferredWidth: 68 }
                ComboBox {
                    id: comboElemento
                    Layout.fillWidth: true
                    model: catalogoValvulas
                    textRole: "etiqueta"
                    valueRole: "codigo"
                }
            }

            // Campo USUARIO
            RowLayout {
                Layout.fillWidth: true
                spacing: 4
                Text { text: "USUARIO:"; color: "#fdbf6f"; font.bold: true; Layout.preferredWidth: 68 }
                TextField {
                    id: txtUsuario
                    Layout.fillWidth: true
                    placeholderText: "Nombre del usuario (opcional)"
                    color: "white"
                    background: Rectangle {
                        color: "#333333"
                        radius: 4
                        border.color: "#555555"
                    }
                }
            }

            // 4. Visor de Perfil Longitudinal
            Rectangle {
                id: contenedorPerfil
                visible: false
                Layout.fillWidth: true
                Layout.preferredHeight: 265
                color: "#141414"
                radius: 8
                border.color: "#444444"
                border.width: 1

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: 8
                    spacing: 6

                    RowLayout {
                        Layout.fillWidth: true
                        Text { text: "Perfil de:"; color: "#00FFFF"; font.bold: true; font.pixelSize: 13 }
                        ComboBox {
                            id: comboRedPerfil
                            Layout.fillWidth: true
                            model: plugin.listaRedes.filter(function(r) { return r !== "Ramal"; })
                            currentIndex: 0
                            onCurrentTextChanged: {
                                var pts = obtenerPuntosPerfil();
                                plugin.indicePuntoPerfil = pts.length - 1;
                                canvasPerfil.requestPaint();
                            }
                        }
                    }

                    Canvas {
                        id: canvasPerfil
                        Layout.fillWidth: true
                        Layout.fillHeight: true

                        onPaint: {
                            var ctx = getContext("2d");
                            ctx.reset();
                            ctx.clearRect(0, 0, width, height);

                            var pts = obtenerPuntosPerfil();
                            var redMostrada = comboRedPerfil.currentText || "Principal";

                            var gpsActivo = false, gpsZ = 0.0, gpsDist = 0.0;
                            var capaRef = obtenerCapaPorNombre("nodos") || obtenerCapaPorNombre("obrasciviles");

                            if (positionSource && positionSource.active && positionSource.positionInformation && capaRef) {
                                var pos = positionSource.positionInformation;
                                if (!isNaN(pos.elevation) && !isNaN(pos.longitude)) {
                                    gpsActivo = true;
                                    gpsZ = pos.elevation;
                                    var pWgs = GeometryUtils.point(pos.longitude, pos.latitude);
                                    var crsWgs = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326");
                                    var pMap = GeometryUtils.reprojectPoint(pWgs, crsWgs, capaRef.crs);

                                    if (pts.length > 0) {
                                        var ult = pts[pts.length - 1];
                                        var dx = pMap.x - ult.x;
                                        var dy = pMap.y - ult.y;
                                        gpsDist = ult.distAcum + Math.sqrt(dx * dx + dy * dy);
                                    }
                                }
                            }

                            if (pts.length === 0) {
                                ctx.fillStyle = "#AAAAAA";
                                ctx.font = "12px sans-serif";
                                ctx.fillText("Sin puntos registrados en '" + redMostrada + "'.", 10, height / 2);
                                return;
                            }

                            var minZ = pts[0].z, maxZ = pts[0].z;
                            var maxDist = pts[pts.length - 1].distAcum;

                            for (var i = 1; i < pts.length; i++) {
                                if (pts[i].z < minZ) minZ = pts[i].z;
                                if (pts[i].z > maxZ) maxZ = pts[i].z;
                            }
                            if (gpsActivo) {
                                if (gpsZ < minZ) minZ = gpsZ;
                                if (gpsZ > maxZ) maxZ = gpsZ;
                                if (gpsDist > maxDist) maxDist = gpsDist;
                            }
                            if (Math.abs(maxZ - minZ) < 2.0) { maxZ += 1.0; minZ -= 1.0; }
                            if (maxDist <= 0.1) maxDist = 10.0;

                            var padL = 42, padR = 16, padT = 18, padB = 20;
                            var w = width - padL - padR;
                            var h = height - padT - padB;

                            ctx.strokeStyle = "#444444";
                            ctx.lineWidth = 1;
                            ctx.beginPath();
                            ctx.moveTo(padL, padT);
                            ctx.lineTo(padL, padT + h);
                            ctx.lineTo(padL + w, padT + h);
                            ctx.stroke();

                            ctx.fillStyle = "#CCCCCC";
                            ctx.font = "10px sans-serif";
                            ctx.fillText(maxZ.toFixed(0) + "m", 2, padT + 8);
                            ctx.fillText(minZ.toFixed(0) + "m", 2, padT + h);
                            ctx.fillText("0+000", padL, height - 4);
                            ctx.fillText(formatearEstacionamiento(maxDist), padL + w - 45, height - 4);

                            ctx.strokeStyle = "#33a02c";
                            ctx.lineWidth = 2.5;
                            ctx.beginPath();
                            for (var k = 0; k < pts.length; k++) {
                                var px = padL + (pts[k].distAcum / maxDist) * w;
                                var py = padT + h - ((pts[k].z - minZ) / (maxZ - minZ)) * h;
                                if (k === 0) ctx.moveTo(px, py);
                                else ctx.lineTo(px, py);
                            }
                            ctx.stroke();

                            if (gpsActivo && pts.length > 0) {
                                var ultPx = padL + (pts[pts.length - 1].distAcum / maxDist) * w;
                                var ultPy = padT + h - ((pts[pts.length - 1].z - minZ) / (maxZ - minZ)) * h;
                                var gpsPx = padL + (gpsDist / maxDist) * w;
                                var gpsPy = padT + h - ((gpsZ - minZ) / (maxZ - minZ)) * h;

                                ctx.strokeStyle = "#00FFFF";
                                ctx.lineWidth = 1.5;
                                ctx.setLineDash([4, 4]);
                                ctx.beginPath();
                                ctx.moveTo(ultPx, ultPy);
                                ctx.lineTo(gpsPx, gpsPy);
                                ctx.stroke();
                                ctx.setLineDash([]);

                                ctx.fillStyle = "#00FFFF";
                                ctx.beginPath();
                                ctx.arc(gpsPx, gpsPy, 5, 0, 2 * Math.PI);
                                ctx.fill();
                                ctx.fillText("Tú", gpsPx - 8, gpsPy - 8);
                            }

                            for (var m = 0; m < pts.length; m++) {
                                var nx = padL + (pts[m].distAcum / maxDist) * w;
                                var ny = padT + h - ((pts[m].z - minZ) / (maxZ - minZ)) * h;

                                if (m === plugin.indicePuntoPerfil) {
                                    ctx.strokeStyle = "#FFFF00";
                                    ctx.lineWidth = 1;
                                    ctx.beginPath();
                                    ctx.moveTo(nx, padT);
                                    ctx.lineTo(nx, padT + h);
                                    ctx.stroke();

                                    ctx.fillStyle = "#FFFF00";
                                    ctx.beginPath();
                                    ctx.arc(nx, ny, 6.5, 0, 2 * Math.PI);
                                    ctx.fill();
                                }

                                ctx.beginPath();
                                if (pts[m].valvula !== "") {
                                    ctx.fillStyle = "#e31a1c";
                                    ctx.arc(nx, ny, 4, 0, 2 * Math.PI);
                                    ctx.fill();

                                    ctx.fillStyle = "#fdbf6f";
                                    ctx.font = "bold 9px sans-serif";
                                    ctx.fillText(pts[m].valvula, nx - 7, ny - 8);
                                } else {
                                    ctx.fillStyle = "#FFFFFF";
                                    ctx.arc(nx, ny, 2.5, 0, 2 * Math.PI);
                                    ctx.fill();
                                }
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: 6

                        Button {
                            text: "◀ Ant."
                            Layout.preferredWidth: 68
                            onClicked: {
                                var pts = obtenerPuntosPerfil();
                                if (pts.length === 0) return;
                                if (plugin.indicePuntoPerfil > 0) plugin.indicePuntoPerfil -= 1;
                                else plugin.indicePuntoPerfil = 0;
                                canvasPerfil.requestPaint();
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            height: 38
                            color: "#222222"
                            radius: 4
                            border.color: "#FFFF00"
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                color: "white"
                                font.pixelSize: 11
                                font.bold: true
                                horizontalAlignment: Text.AlignHCenter
                                text: {
                                    var pts = obtenerPuntosPerfil();
                                    var idx = plugin.indicePuntoPerfil;
                                    if (pts.length === 0 || idx < 0 || idx >= pts.length) return "Sin punto seleccionado";
                                    var p = pts[idx];
                                    var tipo = p.valvula === "" ? "NODO" : p.valvula;
                                    var usr = p.usuario !== "" ? " | Usr: " + p.usuario : "";
                                    return "Pto #" + p.punto + " [" + tipo + "] | Est: " + p.est + "\nZ: " + p.z.toFixed(1) + " m" + usr;
                                }
                            }
                        }

                        Button {
                            text: "Sig. ▶"
                            Layout.preferredWidth: 68
                            onClicked: {
                                var pts = obtenerPuntosPerfil();
                                if (pts.length === 0) return;
                                if (plugin.indicePuntoPerfil < pts.length - 1) plugin.indicePuntoPerfil += 1;
                                else plugin.indicePuntoPerfil = pts.length - 1;
                                canvasPerfil.requestPaint();
                            }
                        }
                    }
                }
            }

            Button {
                Layout.fillWidth: true
                Layout.preferredHeight: 46
                text: "📍 REGISTRAR PUNTO (#" + plugin.contadorPunto + ")"
                font.bold: true
                font.pixelSize: 15
                background: Rectangle {
                    color: parent.down ? "#23701e" : "#33a02c"
                    radius: 8
                }
                contentItem: Text {
                    text: parent.text
                    color: "white"
                    font: parent.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                onClicked: registrarPuntoEnCapas()
            }
        }
    }

    // Inserta un registro en la capa indicada rellenando solo los campos que existan en ella
    function insertarEnCapa(capa, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, esRequeridoRed, faltantesOut) {
        var wkt = "POINT(" + xActual + " " + yActual + ")";
        var geom = GeometryUtils.createGeometryFromWkt(wkt);
        var feature = FeatureUtils.createBlankFeature(capa.fields, geom);
        var campos = capa.fields.names;

        function asignar(nombreCol, valor, avisarSiFalta) {
            var existe = false;
            for (var c = 0; c < campos.length; c++) {
                if (campos[c].toUpperCase() === nombreCol.toUpperCase()) {
                    feature.setAttribute(c, valor);
                    existe = true;
                    break;
                }
            }
            if (!existe && avisarSiFalta && faltantesOut.indexOf(nombreCol) === -1) {
                faltantesOut.push(nombreCol + " en " + capa.name);
            }
        }

        asignar("PUNTO", plugin.contadorPunto, true);
        asignar("COORDEX", Math.round(xActual), true);
        asignar("COORDEY", Math.round(yActual), true);
        asignar("ELEVACION", Math.round(elev * 100) / 100, true);
        asignar("VALVULA", valorValvula, true);
        asignar("RED", redSeleccionada, esRequeridoRed); // Requerido en Nodos, opcional en ObrasCiviles
        asignar("USUARIO", textoUsuario, false);
        asignar("ID_TOMA", 0, false);

        return LayerUtils.addFeature(capa, feature);
    }

    function registrarPuntoEnCapas() {
        if (!positionSource || !positionSource.active || !positionSource.positionInformation) {
            mainWindow.displayToast("⚠️ El GPS no está activo o sin señal.");
            return;
        }

        var redSeleccionada = comboRed.currentText;
        if (redSeleccionada === "Ramal") {
            mainWindow.displayToast("⚠️ Escribe el número en 'N°' y toca '+Ramal' para indicar cuál ramal levantas (ej. Ramal_8).");
            return;
        }

        var capaNodos = obtenerCapaPorNombre("nodos");
        var capaObras = obtenerCapaPorNombre("obrasciviles");
        var capaActiva = (dashBoard && dashBoard.activeLayer && dashBoard.activeLayer.geometryType() === Qgis.GeometryType.Point) ? dashBoard.activeLayer : null;

        var capaRef = capaNodos || capaObras || capaActiva;
        if (!capaRef) {
            mainWindow.displayToast("⚠️ No se encontró la capa Nodos ni ObrasCiviles en el proyecto.");
            return;
        }

        var pos = positionSource.positionInformation;
        var lon = pos.longitude;
        var lat = pos.latitude;
        var elev = isNaN(pos.elevation) ? 0.0 : pos.elevation;

        var puntoWgs84 = GeometryUtils.point(lon, lat);
        var crsWgs84 = CoordinateReferenceSystemUtils.fromDescription("EPSG:4326");
        var puntoTransformado = GeometryUtils.reprojectPoint(puntoWgs84, crsWgs84, capaRef.crs);

        var xActual = puntoTransformado.x;
        var yActual = puntoTransformado.y;

        var codigoSeleccionado = catalogoValvulas.get(comboElemento.currentIndex).codigo;
        var valorValvula = (codigoSeleccionado === "NODO") ? "" : codigoSeleccionado;
        var textoUsuario = txtUsuario.text.trim();

        var distAcumulada = 0.0;
        for (var i = plugin.historialPuntos.length - 1; i >= 0; i--) {
            if (plugin.historialPuntos[i].red === redSeleccionada) {
                var dx = xActual - plugin.historialPuntos[i].x;
                var dy = yActual - plugin.historialPuntos[i].y;
                distAcumulada = plugin.historialPuntos[i].distAcum + Math.sqrt(dx * dx + dy * dy);
                break;
            }
        }
        var estTexto = formatearEstacionamiento(distAcumulada);

        var faltantes = [];
        var guardadoNodos = false;
        var guardadoObras = false;

        // 1. Guardar siempre en la capa Nodos (con RED) para actualizar la red y el perfil
        if (capaNodos) {
            var cantAntes = capaObras ? capaObras.featureCount : -1;
            guardadoNodos = insertarEnCapa(capaNodos, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, true, faltantes);

            // 2. Si es una válvula (VA, VT, TQ, FT, etc.) y ObrasCiviles no comparte el mismo archivo físico, agregarlo también a ObrasCiviles para que muestre el símbolo
            if (valorValvula !== "" && capaObras && capaObras !== capaNodos) {
                if (capaObras.featureCount === cantAntes) {
                    guardadoObras = insertarEnCapa(capaObras, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, false, faltantes);
                } else {
                    guardadoObras = true; // Ya se agregó automáticamente porque comparten el mismo shapefile
                }
            }
        } else if (capaObras) {
            guardadoObras = insertarEnCapa(capaObras, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, false, faltantes);
        } else if (capaActiva) {
            guardadoNodos = insertarEnCapa(capaActiva, xActual, yActual, elev, valorValvula, redSeleccionada, textoUsuario, true, faltantes);
        }

        if (guardadoNodos || guardadoObras) {
            if (mapCanvas) mapCanvas.refresh();

            var nuevoHistorial = plugin.historialPuntos.slice();
            nuevoHistorial.push({
                punto: plugin.contadorPunto,
                red: redSeleccionada,
                valvula: valorValvula,
                x: xActual,
                y: yActual,
                z: elev,
                distAcum: distAcumulada,
                est: estTexto,
                usuario: textoUsuario
            });
            plugin.historialPuntos = nuevoHistorial;

            var ptsPerfil = obtenerPuntosPerfil();
            plugin.indicePuntoPerfil = ptsPerfil.length - 1;
            if (contenedorPerfil.visible) {
                canvasPerfil.requestPaint();
            }

            var etq = valorValvula === "" ? "NODO" : valorValvula;
            if (faltantes.length > 0) {
                mainWindow.displayToast("⚠️ Guardado #" + plugin.contadorPunto + " [" + etq + "]. Campos inexistentes omitidos: " + faltantes.join(", "));
            } else {
                var destinoMsg = (valorValvula !== "") ? "Nodos + ObrasCiviles" : "Nodos";
                mainWindow.displayToast("✅ #" + plugin.contadorPunto + " [" + etq + "] en " + redSeleccionada + " (" + destinoMsg + ")");
            }

            plugin.contadorPunto += 1;
            comboElemento.currentIndex = 0; // Auto-retorno a NODO
            txtUsuario.text = "";
        } else {
            mainWindow.displayToast("❌ No se pudo guardar el punto. Verifica que las capas Nodos y ObrasCiviles sean editables en QField.");
        }
    }
}